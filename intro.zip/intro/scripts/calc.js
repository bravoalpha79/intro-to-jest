const addition = (a, b) => a + b;

module.exports = addition; 