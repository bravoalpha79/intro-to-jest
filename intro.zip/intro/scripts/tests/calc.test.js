const addition = require("../calc");

describe ("Calculator", () => {
    describe("Addition function", () => {
        test("should return 42 for 20 + 22", () => {
            expect(addition(20, 22)).toBe(42);
        });
        test("should return 35 for 19 + 16", () => {
            expect(addition(19, 16)).toBe(35);
        });
    });
    describe("Subtraction function", () => {
        
    });
    describe("Multiplication function", () => {
        
    });
    describe("Division function", () => {
        
    });
});